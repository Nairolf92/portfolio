[poo][php5]un site multilangue via xml--------------------------------------
Url     : http://codes-sources.commentcamarche.net/source/50416-poo-php5-un-site-multilangue-via-xmlAuteur  : destinyfrDate    : 18/08/2013
Licence :
=========

Ce document intitul� � [poo][php5]un site multilangue via xml � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour &agrave; tous et &agrave; toutes !
<br />
<br />Dans le but de contrib
uer comme la plus part des personnes ici, je propose une classe permettant de g&
eacute;rer diff&eacute;rentes langues sur son site avec l'utilisation d'XML (Sim
pleXML dans mon cas). Ce n'est surement pas la meilleur fa&ccedil;on de faire ce
ci, mais bon je propose ma solution, elle marche tr&egrave;s bien (pour ma part 
^^) et elle n'est pas tr&egrave;s dur &agrave; comprendre.
<br />
<br />Il fau
t cr&eacute;er un dossier contenant les langues et placer les langues comme ceci
 : fr/page.xml, de/page.xml, en/page.xml, ja/page.xml etc...
<br />
<br />Je p
r&eacute;cise aussi que pour g&eacute;rer le japonais etc... j'encode mes fichie
r en utf-8 sans BOM ! (si ce n'est pas les cas, les accents etc... seront affich
&eacute;s bizarrement). Ici les fichiers sont encod&eacute;s comme y faut (pour 
l'archive).
<br /><a name='source-exemple'></a><h2> Source / Exemple : </h2>

<br /><pre class='code' data-mode='basic'>
Fichier Langues.class.php :
&lt;?ph
p
error_reporting(E_ALL &amp; ~E_NOTICE);

class Langues {
	// Langue par le
 code ISO 639 (d�faut : fran�ais)
	private $_langue = 'fr';
	
	// Dossier con
tenant les langues
	private $_dirLangue = '';
	
	// Objet SimpleXML
	private
 $_simpleXML = null;
	
	/*
	Constructeur
	
	R�cup�re la langue via le navig
ateur, sinon charge celle par d�faut ou si une langue est sp�cifi�e, on charge c
elle ci. Permet aussi de sp�cifier le dossier o� ce trouvent les langues
	
	@a
ccess public
	@param $langue, $dirLangue, $fichier
	@return void

<ul>	<li>/
</li></ul>
	public function __construct($dirLangue, $fichier, $langue = false) 
{
		if(is_dir($dirLangue)) {
			$this-&gt;_dirLangue = $dirLangue;
		}
		els
e {
			$this-&gt;_dirLangue = 'langues';
		}
		
		if($langue) {
			$this-&g
t;_langue = strtolower($langue);
		}
		else {
			if($lang = strtolower(substr
($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2))) {
				$this-&gt;_langue = $lang;
		
	}
			else {
				$this-&gt;_langue = 'fr';
			}
		}
		
		if(file_exists($t
his-&gt;_dirLangue.'/'.$this-&gt;_langue.'/'.$fichier.'.xml')) {
			// Chargeme
nt du fichier langue
			$this-&gt;loadXmlFile($fichier);
		}
		else {
			die
('Fichier XML ('.$this-&gt;_dirLangue.'/'.$this-&gt;_langue.'/'.$fichier.'.xml) 
innexistant ! Merci de v�rifier que celui ci existe.');
		}
	}
	
	/*
	Charg
e le fichier XML
	
	@access private
	@param $fichier
	@return void

<ul>	<
li>/</li></ul>
	private function loadXmlFile($fichier) {
		$this-&gt;_simpleXM
L = simplexml_load_file($this-&gt;_dirLangue.'/'.$this-&gt;_langue.'/'.$fichier.
'.xml');
	}
	
	/*
	Charge le message � afficher
	
	@access public
	@param
 $texte
	@return $texte

<ul>	<li>/</li></ul>
	public function show_text($te
xte) {
		$resultat = $this-&gt;_simpleXML-&gt;xpath($texte);
		
		foreach($re
sultat as $noeud) {
			return $noeud;
		}
	}
}
?&gt;

Fichier fr/index.xm
l :
&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot;?&gt;
&lt;langu
e&gt;
	&lt;msg_test&gt;Bonjour le monde&lt;/msg_test&gt;
&lt;/langue&gt;

Fi
chier en/index.xml :
&lt;?xml version=&quot;1.0&quot; encoding=&quot;utf-8&quot
;?&gt;
&lt;langue&gt;
	&lt;msg_test&gt;Hello world&lt;/msg_test&gt;
&lt;/lang
ue&gt;

Fichier de/index.xml :
&lt;?xml version=&quot;1.0&quot; encoding=&quo
t;utf-8&quot;?&gt;
&lt;langue&gt;
	&lt;msg_test&gt;Hallo Welt&lt;/msg_test&gt;

&lt;/langue&gt;

Fichier ja/index.xml :
&lt;?xml version=&quot;1.0&quot; en
coding=&quot;utf-8&quot;?&gt;
&lt;langue&gt;
	&lt;msg_test&gt;&amp;#12371;&amp
;#12435;&amp;#12395;&amp;#12385;&amp;#12399;&lt;/msg_test&gt;
&lt;/langue&gt;


Fichier test.php :
&lt;?php
// Chargement de la classe
include_once('Langue
s.class.php');

// Cr�ation d'un nouvel objet Langue avec comme param�tres le 
dossier langue et le fichier xml � charger (et en facultatif une session contena
nt la langue � charger, peut �tre utilis� dans un syst�me de membre, avec une se
ssion contenant la langue du membre).
$langue = new Langues('langues', 'index')
;
// $langue = new Langues('langues', 'index', 'ja');
?&gt;
&lt;!DOCTYPE html
 PUBLIC &quot;-//W3C//DTD XHTML 1.0 Strict//EN&quot; &quot;<a href='http://www.w
3.org/TR/xhtml1/DTD/xhtml1-strict.dtd' target='_blank'>http://www.w3.org/TR/xhtm
l1/DTD/xhtml1-strict.dtd</a>&quot;&gt;
&lt;html xmlns=&quot;<a href='http://www
.w3.org/1999/xhtml' target='_blank'>http://www.w3.org/1999/xhtml</a>&quot;&gt;

&lt;head&gt;
	&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/h
tml; charset=utf-8&quot; /&gt;
	&lt;title&gt;test du multilangue&lt;/title&gt;

&lt;/head&gt;
&lt;body&gt;
&lt;?php
// Et on affiche du texte
echo $langue-
&gt;show_text('msg_test');
?&gt;
&lt;/body&gt;
&lt;/html&gt;
</pre>
<br /><
a name='conclusion'></a><h2> Conclusion : </h2>
<br />Voil&agrave; le code sou
rce est donn&eacute;, je suis d&eacute;sol&eacute; pour l'orthographe (&ccedil;a
 m'&eacute;tonnerai qu'il n'y est pas de fautes &gt;.&lt;).
<br />
<br />Pour 
l'utilisation, c'est tr&egrave;s simple :
<br />
<br />&lt;?php
<br />// Char
gement de la classe
<br />include_once('Langues.class.php');
<br />
<br />// 
Cr&eacute;ation d'un nouvel objet Langue avec comme param&egrave;tres le dossier
 langue et le fichier xml &agrave; charger (et en facultatif une session contena
nt la langue &agrave; charger, peut &ecirc;tre utilis&eacute; dans un syst&egrav
e;me de membre, avec une session contenant la langue du membre).
<br />$langue 
= new Langues('langues', 'index');
<br />// $langue = new Langues('langues', 'i
ndex', 'ja');
<br />?&gt;
<br />&lt;!DOCTYPE html PUBLIC &quot;-//W3C//DTD XHT
ML 1.0 Strict//EN&quot; &quot;<a href='http://www.w3.org/TR/xhtml1/DTD/xhtml1-st
rict.dtd' target='_blank'>http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd</a>&
quot;&gt;
<br />&lt;html xmlns=&quot;<a href='http://www.w3.org/1999/xhtml' tar
get='_blank'>http://www.w3.org/1999/xhtml</a>&quot;&gt;
<br />&lt;head&gt;
<br
 />	&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charse
t=utf-8&quot; /&gt;
<br />	&lt;title&gt;test du multilangue&lt;/title&gt;
<br 
/>&lt;/head&gt;
<br />&lt;body&gt;
<br />&lt;?php
<br />// Et on affiche du t
exte
<br />echo $langue-&gt;show_text('msg_test');
<br />?&gt;
<br />&lt;/bod
y&gt;
<br />&lt;/html&gt;
<br />
<br />Ce code affichera : Hello world en ang
lais, Bonjour le monde en fran&ccedil;ais, Hallo Welt en allemand, &#12371;&#124
35;&#12395;&#12385;&#12399; en japonais etc...
<br />
<br />Voil&agrave; merci
 de commenter cette source et de donner vos avis, remarques etc...
<br />
<br 
/>Bonne journ&eacute;e ;)
