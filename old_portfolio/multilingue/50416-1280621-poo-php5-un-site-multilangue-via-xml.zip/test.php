<?php
// Chargement de la classe
include_once('Langues.class.php');

// Création d'un nouvel objet Langue avec comme paramètres le dossier langue et le fichier xml à charger (et en facultatif une session contenant la langue à charger, peut être utilisé dans un système de membre, avec une session contenant la langue du membre).
$langue = new Langues('langues', 'index');
// $langue = new Langues('langues', 'index', 'ja');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>test du multilangue</title>
</head>
<body>
<?php
// Et on affiche du texte
echo $langue->show_text('msg_test');
?>
</body>
</html>