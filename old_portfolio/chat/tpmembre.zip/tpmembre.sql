-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 21 Décembre 2015 à 19:51
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `tpmembre`
--

-- --------------------------------------------------------

--
-- Structure de la table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `chat`
--

INSERT INTO `chat` (`id`, `pseudo`, `message`) VALUES
(4, 'oh', 'dad'),
(5, 'oh', 'da'),
(6, 'oh', 'Le Lorem Ipsum est simplement du faux texte'),
(7, 'oh', 'Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression'),
(8, 'aaa', 'C''est bien vrai !'),
(9, 'aaa', 'C''est pas faux'),
(10, 'aaa', 'Ca marche !');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `date_inscription` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `pass`, `mail`, `date_inscription`) VALUES
(2, 'Premier', '916a78d701ded328cd66da58a97ef8cd28a99e84', 'first@first.fr', '2015-12-13'),
(4, 'Test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'test@gmail.com', '2015-12-21'),
(5, 'bla', 'ffa6706ff2127a749973072756f83c532e43ed02', 'f.kelnerowski@gmail.com', '2015-12-21'),
(6, 'oh', '51e2d5188e8c471593577484b83cd5b998deb6a3', 'f.kelnerowski@gmail.com', '2015-12-21'),
(7, 'brah', '695d1218171016ba0addc51a2d1f01e375077539', 'f.kelnerowski@gmail.com', '2015-12-21'),
(8, 'Bloppy', '695d1218171016ba0addc51a2d1f01e375077539', 'f.kelnerowski@gmail.com', '2015-12-21'),
(9, 'www', 'c50267b906a652f2142cfab006e215c9f6fdc8a0', 'fazfa@aekla.fr', '2015-12-21'),
(10, 'aaa', '7e240de74fb1ed08fa08d38063f6a6a91462a815', 'f.kelnerowski@gmail.com', '2015-12-21');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
